# Improve Your LinkedIn Profile

## [1. Overview](https://classroom.udacity.com/nanodegrees/nd0044/parts/838df8a7-4694-4982-a9a5-a5ab20247776/modules/afbae13a-a91a-4d5e-9f98-4fe13c415f7a/lessons/1de68fcc-5fec-422c-b1a9-69deba3e3d04/concepts/434d8a78-81f5-4ac3-a6a3-5f38d1fe9990)

[![](https://img.youtube.com/vi/Au1u_BntJ-w/0.jpg)](https://youtu.be/Au1u_BntJ-w)

Now that you've learned the ins and outs of creating a RESTful API, you'll learn about how to make your API accessible and usable for other developers. In this course we will cover:
1. Good vs. Bad API Documentation
2. Practice writing API Documentation
3. Project Documentation

