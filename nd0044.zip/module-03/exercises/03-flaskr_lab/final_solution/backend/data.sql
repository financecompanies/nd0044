insert into
    books (id, title, author, rating)
values
    (3, 'The Great Alone', 'Kristin Hannah', 4),
    (6, 'Lullaby', 'Leila Slimani', 2),
    (7, 'Immigrant, Montana', 'Amitava Kumar', 5),
    (13, 'All We Ever Wanted', 'Emily Giffin', 4),
    (14, 'We Fed an Island', 'Jose Andres', 4),
    (
        16,
        'The Maze at Windermere',
        'Gregory Blake Smith',
        2
    ),
    (4, 'Educated: A Memoir', 'Tara Westover', 5),
    (10, 'An American Marriage', 'Tayari Jones', 5),
    (8, 'CIRCE', 'Madeline Miller', 5),
    (
        11,
        '12 Rules for Life: An Antidote to Chaos',
        'Jordan B. Peterson',
        5
    ),
    (
        12,
        'Heavy: An American Memoir',
        'Kiese Laymon',
        1
    ),
    (15, 'The Mars Room', 'Rachel Kushner', 1),
    (1, 'The Outsider: A Novel', 'Stephen King', 5),
    (2, 'Asymmetry: A Novel', 'Lisa Halliday', 4),
    (9, 'Insurrecto: A Novel', 'Gina Apostol', 5),
    (5, 'Still Me: A Novel', 'Jojo Moyes', 5)