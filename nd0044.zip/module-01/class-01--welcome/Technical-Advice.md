# Technical Advice

* Coding requires debugging

* Seek solutions

* Look at successful examples

* Build code incrementally