# Welcome to the Program!

Here are the tips to reach the success in this program:
* [Goals](Goals.md)
* [Learning Strategies](Learning-Strategies.md)
* [Technical Advice](Technical-Advice.md)
* [How to Succeed - Summary](How-to-Succeed-Summary.md)