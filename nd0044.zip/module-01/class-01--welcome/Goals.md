# Goals

* Define learning path

* Define goals

* Goal could be to learn more

* Keep goals in mind

* Set short and long term goals

* Create an incremental plan