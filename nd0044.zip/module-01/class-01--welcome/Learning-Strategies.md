# Learning Strategies

* Break code logic into pseudocode

* Be patient with yourself

* Remember your goals