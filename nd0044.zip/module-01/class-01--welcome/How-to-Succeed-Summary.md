# How to Succeed - Summary

* Set goals and accountability measures
    - [x] Add [calendar reminder](https://calendar.google.com/calendar/embed?src=t9dblmtosngla9atktqf766hugrue4pt%40import.calendar.google.com&ctz=America%2FSao_Paulo)
    - [x] Setup [gitlab repository](https://gitlab.com/full-stack-developer-nanodegree--nd0044) with wiki, issues, labels and milestones
    - [ ] Share online my achievements (work in progress)

* Break down goals into smaller goals

* Focus on smaller goals

* Work through exercises

* Pseudocode first, code last